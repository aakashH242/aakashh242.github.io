# Live Security Evidence

- Evidence root: `D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410`
- Generated at: `20260316-221429`
- Overall verdict: `PASS`

## Setup

- Mutable FastMCP upstream served over Streamable HTTP.
- One or more local adapter instances started with scenario-specific YAML configs.
- Raw tool catalogs, error payloads, SQLite state snapshots, configs, and process logs saved per scenario.

## Scenario 1 - Tool Definition Pinning

### Setup

- Mock upstream on one mutable FastMCP server.
- Adapter configured with tool_definition_pinning.mode=block, block_strategy=error, and block_error_session_action=invalidate.
- Direct adapter tools/list used so the first catalog exposure pins the session baseline.

### What We Ran

- `D:\python_projects\opensource-contribs\remote-mcp-relay\.venv\Scripts\python.exe mock_tool_drift_upstream.py --host 127.0.0.1 --port 8765 --path /mcp --initial-revision baseline --no-banner`
- `D:\python_projects\opensource-contribs\remote-mcp-relay\.venv\Scripts\python.exe -m remote_mcp_adapter --config D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-1-tool-definition-pinning\adapter-config.yaml --host 127.0.0.1 --port 8940`

### Observations

- Initial adapter session pinned with session id `b5d99f3c6b40433f97802d0f965b6d4b`.
- Same-session drift response: Tool definition drift detected for this adapter session. The current session was invalidated. Start a new Mcp-Session-Id to accept upstream tool updates. Drift: changed=mutable_echo[description]
- Repeated reuse of the invalidated session was rejected again: Client error '409 Conflict' for url 'http://127.0.0.1:8940/mcp/drift'
For more information check: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/409
- A fresh session listed the upgraded tool catalog successfully.
- The persisted SQLite state now contains the terminal tombstone for the invalidated session.

### Final Verdict

- `PASS`
- Pass. The adapter pinned the first tool catalog, detected description drift mid-session, invalidated the old session, and required a fresh Mcp-Session-Id before accepting the upgraded catalog.
- Evidence folder: `D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-1-tool-definition-pinning`

## Scenario 2 - Tool Metadata Sanitization

### Setup

- Mock upstream revision dirty_metadata exposes zero-width characters, decomposed Unicode, and dirty schema text.
- One adapter run uses tool_metadata_sanitization.mode=sanitize.
- A second adapter run uses tool_metadata_sanitization.mode=block.

### What We Ran

- `D:\python_projects\opensource-contribs\remote-mcp-relay\.venv\Scripts\python.exe -m remote_mcp_adapter --config D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-2-tool-metadata-sanitization\sanitize-config.yaml --host 127.0.0.1 --port 8941`
- `D:\python_projects\opensource-contribs\remote-mcp-relay\.venv\Scripts\python.exe -m remote_mcp_adapter --config D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-2-tool-metadata-sanitization\block-config.yaml --host 127.0.0.1 --port 8942`

### Observations

- Upstream dirty title: 'Café\u200b Tool'
- Sanitized title: 'Café Tool'
- Upstream dirty description: 'Café\u200b tool\u200b description with invisible format characters.'
- Sanitized description: 'Café tool description with invisible format characters.'
- Upstream dirty schema description: 'Café\u200b schema\u200b description with invisible format characters and mixed unicode form.'
- Sanitized schema description: 'Café schema description with invisible format characters and mixed unicode form.'
- When mode=block, the dirty tool disappeared from the visible catalog instead of being forwarded unchanged.

### Final Verdict

- `PASS`
- Pass. The sanitize mode cleaned model-visible metadata before forwarding it, and the block mode removed the dirty tool from the adapter catalog entirely.
- Evidence folder: `D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-2-tool-metadata-sanitization`

## Scenario 3 - Tool Description Policy

### Setup

- Mock upstream revision verbose_descriptions exposes very long top-level and nested schema descriptions.
- One adapter run uses tool_description_policy.mode=truncate with small character caps.
- A second adapter run uses tool_description_policy.mode=strip.

### What We Ran

- `D:\python_projects\opensource-contribs\remote-mcp-relay\.venv\Scripts\python.exe -m remote_mcp_adapter --config D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-3-tool-description-policy\truncate-config.yaml --host 127.0.0.1 --port 8943`
- `D:\python_projects\opensource-contribs\remote-mcp-relay\.venv\Scripts\python.exe -m remote_mcp_adapter --config D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-3-tool-description-policy\strip-config.yaml --host 127.0.0.1 --port 8944`

### Observations

- Upstream tool description length: 812 characters.
- Truncated tool description length: 120 characters.
- Upstream schema description length: 740 characters.
- Truncated schema description length: 80 characters.
- Strip mode tool description: None
- Strip mode schema description: None

### Final Verdict

- `PASS`
- Pass. The global description policy shaped all tools, including nested schema descriptions. Truncate mode bounded the prose, and strip mode removed it entirely.
- Evidence folder: `D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-3-tool-description-policy`

## Scenario 4 - Session Integrity Hardening

### Setup

- Adapter auth enabled with a custom x-adapter-auth header.
- Disk-backed state persistence kept the same session store across the restart.
- The first authenticated stateful request binds the adapter session to the auth-token fingerprint.

### What We Ran

- `D:\python_projects\opensource-contribs\remote-mcp-relay\.venv\Scripts\python.exe -m remote_mcp_adapter --config D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-4-session-integrity\alpha-config.yaml --host 127.0.0.1 --port 8945`
- `D:\python_projects\opensource-contribs\remote-mcp-relay\.venv\Scripts\python.exe -m remote_mcp_adapter --config D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-4-session-integrity\beta-config.yaml --host 127.0.0.1 --port 8946`

### Observations

- Initial adapter session id: ed9f04771b0d4d38ab3bd1eac778728f
- Reuse with rotated auth token failed with: Client error '409 Conflict' for url 'http://127.0.0.1:8946/mcp/drift'
For more information check: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/409
- Fresh beta session id: 189b1cf645b44ffbba26fe384f8778b9
- Persisted trust-context fingerprints: ['3e9f85b9425c13d4d7714e167079dde38676d69837a2bc889647339e9c9e4458', '5a70930bf7da8ec98e4dd211cf996e738313cfd6d7b0b147ce248bb3e79d5f35']
- The state store preserved the old alpha-bound session and then bound a new beta-authenticated session separately.

### Final Verdict

- `PASS`
- Pass. The adapter bound the original session to the first adapter-auth context, rejected reuse of that session under a rotated token, and allowed a fresh session to establish a new trust binding.
- Evidence folder: `D:\python_projects\opensource-contribs\remote-mcp-relay\self-test-scripts\evidence\security-live-20260316-221410\scenario-4-session-integrity`
